For the n-queens problem, I know there are row, col, and diagonal constraints.
I incorporated the row constraints into the representation of the problem. I know that
each queen must be in a different row, so instead of assigning 2D point values to each queen, I
assign the columns that the queens are in (A-E), which each queen taking up a row respectively.
I can just use the not equal constraints to make sure the queens are all in different columns.
I also added four new binary constraints to check if two queens are in the one, two, three, or four
diagonals adjacent to each other. As such, the 5 queens problem can be represented with only
20 binary constraints. An n-queens problem will require (n(n-1))/2 not equal constraints and
the same number of diagonal constraints. n(n-1) binary constraints in all. In this csp file,
I did 5-queens, but could have easily expanded it to more following the same train of thought.

To Run:

I already included q7 in my Extra autograder and the q7 folder in my extra folder.

You can run 'python autograder.py' in the root directory to grade q1-6 normally, then just cd into Extra and grade q7 by itself using 'python autograder.py -q q7'.