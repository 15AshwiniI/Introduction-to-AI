# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called
by Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other
    maze, the sequence of moves will be incorrect, so only use this for tinyMaze
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s,s,w,s,w,w,s,w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first

    Your search algorithm needs to return a list of actions that reaches
    the goal.  Make sure to implement a graph search algorithm

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
"""
    # print "Hello"
    # print "Start:", problem.getStartState()
    # print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    # print "Start's successors:", problem.getSuccessors(problem.getStartState())
    
    newList = []
    startNode = (problem.getStartState(), newList, )
    
    myStack = util.Stack()
    myStack.push(startNode)
    visited = [] #logn list, hashset constant
    currentNode = None
    reachedGoal = False
    while(not myStack.isEmpty() and not reachedGoal):
        currentNode = myStack.pop()
        #when you reach goal state you can stop
        if problem.isGoalState(currentNode[0]):
            reachedGoal = True
            continue
        visited.append(currentNode[0])
        for successor in problem.getSuccessors(currentNode[0]):
            if successor[0] not in visited:
                if currentNode[1] is not None:
                    tempList = list(currentNode[1])
                    tempList.append(successor[1])
                    myStack.push((successor[0], tempList, ))
                else:
                    tempList = []
                    tempList.append(sucessor[1])
                    myStack.push((successor[0], tempList, ))
    return currentNode[1] if problem.isGoalState(currentNode[0]) else []

def breadthFirstSearch(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    #util.raiseNotDefined()
    newList = []
    startNode = (problem.getStartState(), newList, )
    
    myQueue = util.Queue()
    myQueue.push(startNode)
    visited = [] #logn list, hashset constant
    currentNode = None
    reachedGoal = False
    while(not myQueue.isEmpty() and not reachedGoal):
        currentNode = myQueue.pop()
        if problem.isGoalState(currentNode[0]):
            reachedGoal = True
            continue
        visited.append(currentNode[0])
        for successor in problem.getSuccessors(currentNode[0]):
            if successor[0] not in visited:
                visited.append(successor[0])
                if currentNode[1] is not None:
                    tempList = list(currentNode[1])
                    tempList.append(successor[1])
                    myQueue.push((successor[0], tempList, ))
                else:
                    tempList = []
                    tempList.append(sucessor[1])
                    myQueue.push((successor[0], tempList, ))
    return currentNode[1] if problem.isGoalState(currentNode[0]) else []

def uniformCostSearch(problem):
    "Search the node of least total cost first. "
    #util.raiseNotDefined()
    newList = []
    currCost = 0
    startNode = (problem.getStartState(), newList, currCost)
    myPq = util.PriorityQueue()
    myPq.push(startNode, startNode[2])
    myList = [startNode]
    visitedList = []
    reachedGoal = False
    while(not myPq.isEmpty() and not reachedGoal):
        currentNode = myPq.pop()
        visitedList.append(currentNode[0])
        if(problem.isGoalState(currentNode[0])):
            reachedGoal = True
            continue
        for successor in problem.getSuccessors(currentNode[0]):
            if successor[0] not in visitedList or problem.isGoalState(successor[0]):
                # Making new node
                tempList = list(currentNode[1])
                tempList.append(successor[1])
                newCost = problem.getCostOfActions(tempList)
                successorNode = (successor[0], tempList, newCost)
                visitedList.append(successor[0])
                if successor[0] not in myList:
                    myPq.push(successorNode, newCost)
                    myList.append(successorNode)
                else:
                    nodeLoc = myList.index(successor[0])
                    value = myList[nodeLoc]
                    if(successorNode[2] < value[2]):
                        #set values path to be succesors
                        value[1] = successor[1]
                        value[2] = successorNode[2]
                        myPq.push(value, value[2])
                    else:
                        tempList = []
                        tempList.append(sucessor[1])
                        myQueue.push((successor[0], tempList, ))
    return currentNode[1] if problem.isGoalState(currentNode[0]) else []

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    "Search the node that has the lowest combined cost and heuristic first."
    #util.raiseNotDefined()
    newList = []
    currCost = 0
    startNode = (problem.getStartState(), newList, currCost, heuristic(problem.getStartState(), problem))
    myPq = util.PriorityQueue()
    myPq.push(startNode, startNode[2]+startNode[3])
    myList = [startNode]
    visitedList = []
    reachedGoal = False
    while(not myPq.isEmpty() and not reachedGoal):
        currentNode = myPq.pop()
        visitedList.append(currentNode[0])
        if(problem.isGoalState(currentNode[0])):
            reachedGoal = True
            continue
        for successor in problem.getSuccessors(currentNode[0]):
            if successor[0] not in visitedList or problem.isGoalState(successor[0]):
                tempList = list(currentNode[1])
                tempList.append(successor[1])
                newCost = problem.getCostOfActions(tempList)
                heuristicCost = heuristic(successor[0], problem)
                successorNode = (successor[0], tempList, newCost, heuristicCost)
                visitedList.append(successor[0])
                if successor[0] not in myList:
                    myPq.push(successorNode, newCost+heuristicCost)
                    myList.append(successorNode)
                else:
                    nodeLoc = myList.index(successor[0])
                    value = myList[nodeLoc]
                    if(successorNode[2] < value[2]):
                        #set values path to be succesors
                        value[1] = successor[1]
                        value[2] = successorNode[2]
                        myPq.push(value, value[2]+value[3])
    return currentNode[1] if problem.isGoalState(currentNode[0]) else []



# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
